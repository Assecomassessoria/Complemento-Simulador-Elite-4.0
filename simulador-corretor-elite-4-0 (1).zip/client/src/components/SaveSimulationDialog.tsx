import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Save } from "lucide-react";

interface SaveSimulationDialogProps {
  onSave: (nome: string, descricao: string) => void;
  trigger?: React.ReactNode;
}

export default function SaveSimulationDialog({ onSave, trigger }: SaveSimulationDialogProps) {
  const [open, setOpen] = useState(false);
  const [nome, setNome] = useState("");
  const [descricao, setDescricao] = useState("");
  const [error, setError] = useState("");

  const handleSave = () => {
    if (!nome.trim()) {
      setError("Nome é obrigatório");
      return;
    }

    onSave(nome.trim(), descricao.trim());
    setNome("");
    setDescricao("");
    setError("");
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button className="bg-amber-600 hover:bg-amber-700 text-white">
            <Save className="w-4 h-4 mr-2" />
            Salvar Simulação
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="bg-slate-800 border-slate-700">
        <DialogHeader>
          <DialogTitle className="text-white">Salvar Simulação</DialogTitle>
          <DialogDescription className="text-slate-400">
            Dê um nome e descrição para esta simulação para poder recuperá-la depois.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label htmlFor="nome" className="text-slate-300">
              Nome da Simulação *
            </Label>
            <Input
              id="nome"
              placeholder="Ex: Negociação Cliente XYZ"
              value={nome}
              onChange={(e) => {
                setNome(e.target.value);
                setError("");
              }}
              className="bg-slate-700 border-slate-600 text-white mt-2"
            />
            {error && <p className="text-red-400 text-sm mt-1">{error}</p>}
          </div>

          <div>
            <Label htmlFor="descricao" className="text-slate-300">
              Descrição (opcional)
            </Label>
            <Textarea
              id="descricao"
              placeholder="Ex: Imóvel na Zona Sul, cliente com entrada de 15%..."
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white mt-2 resize-none"
              rows={3}
            />
          </div>

          <div className="flex gap-3 justify-end">
            <Button
              variant="outline"
              onClick={() => setOpen(false)}
              className="border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleSave}
              className="bg-amber-600 hover:bg-amber-700 text-white"
            >
              <Save className="w-4 h-4 mr-2" />
              Salvar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
