import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Trash2, Copy, Calendar, DollarSign, CheckCircle2, AlertCircle } from "lucide-react";
import { formatCurrency } from "@/lib/simulatorCalc";
import { SimulationRecord } from "@/hooks/useSimulationHistory";

interface HistoryPanelProps {
  history: SimulationRecord[];
  onLoadSimulation: (record: SimulationRecord) => void;
  onDeleteSimulation: (id: string) => void;
  onClearHistory: () => void;
}

export default function HistoryPanel({
  history,
  onLoadSimulation,
  onDeleteSimulation,
  onClearHistory,
}: HistoryPanelProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [showConfirmClear, setShowConfirmClear] = useState(false);

  const filteredHistory = history.filter(
    (record) =>
      record.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.descricao?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-white">Histórico de Simulações</CardTitle>
            <CardDescription className="text-slate-400">
              {history.length} simulação{history.length !== 1 ? "s" : ""} salva{history.length !== 1 ? "s" : ""}
            </CardDescription>
          </div>
          {history.length > 0 && (
            <Dialog open={showConfirmClear} onOpenChange={setShowConfirmClear}>
              <DialogTrigger asChild>
                <Button
                  variant="destructive"
                  size="sm"
                  className="bg-red-600 hover:bg-red-700"
                >
                  Limpar Tudo
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-slate-800 border-slate-700">
                <DialogHeader>
                  <DialogTitle className="text-white">Limpar Histórico?</DialogTitle>
                  <DialogDescription className="text-slate-400">
                    Esta ação não pode ser desfeita. Todas as {history.length} simulações serão deletadas.
                  </DialogDescription>
                </DialogHeader>
                <div className="flex gap-3 justify-end">
                  <Button
                    variant="outline"
                    onClick={() => setShowConfirmClear(false)}
                    className="border-slate-600 text-slate-300 hover:bg-slate-700"
                  >
                    Cancelar
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={() => {
                      onClearHistory();
                      setShowConfirmClear(false);
                    }}
                    className="bg-red-600 hover:bg-red-700"
                  >
                    Deletar Tudo
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {history.length > 0 && (
          <div>
            <Label className="text-slate-300">Pesquisar simulações</Label>
            <Input
              placeholder="Digite o nome ou descrição..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white mt-2"
            />
          </div>
        )}

        {history.length === 0 ? (
          <Alert className="border-slate-600 bg-slate-700">
            <AlertCircle className="h-4 w-4 text-slate-400" />
            <AlertDescription className="text-slate-400">
              Nenhuma simulação salva ainda. Crie uma simulação e clique em "Salvar Simulação" para começar.
            </AlertDescription>
          </Alert>
        ) : filteredHistory.length === 0 ? (
          <Alert className="border-slate-600 bg-slate-700">
            <AlertCircle className="h-4 w-4 text-slate-400" />
            <AlertDescription className="text-slate-400">
              Nenhuma simulação encontrada com "{searchTerm}".
            </AlertDescription>
          </Alert>
        ) : (
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {filteredHistory.map((record) => (
              <div
                key={record.id}
                className="p-4 bg-slate-700 rounded-lg border border-slate-600 hover:border-slate-500 transition-colors"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-white font-semibold truncate">{record.nome}</h4>
                      {record.validacaoEntrada === "OK ENTRADA" && (
                        <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0" />
                      )}
                    </div>

                    {record.descricao && (
                      <p className="text-slate-400 text-sm mb-2 truncate">{record.descricao}</p>
                    )}

                    <div className="grid grid-cols-2 gap-2 text-sm mb-2">
                      <div className="flex items-center gap-1 text-slate-300">
                        <DollarSign className="w-3 h-3" />
                        <span>{formatCurrency(record.valorImovel)}</span>
                      </div>
                      <div className="flex items-center gap-1 text-slate-300">
                        <span>📅 {record.prazoParcela} meses</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 text-xs text-slate-500">
                      <Calendar className="w-3 h-3" />
                      <span>{formatDate(record.timestamp)}</span>
                    </div>
                  </div>

                  <div className="flex gap-2 flex-shrink-0">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onLoadSimulation(record)}
                      className="border-slate-600 text-slate-300 hover:bg-slate-600"
                      title="Carregar esta simulação"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => onDeleteSimulation(record.id)}
                      className="bg-red-600 hover:bg-red-700"
                      title="Deletar simulação"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
