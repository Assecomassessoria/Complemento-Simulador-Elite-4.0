import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { X, TrendingUp } from "lucide-react";
import { formatCurrency } from "@/lib/simulatorCalc";
import { SimulationRecord } from "@/hooks/useSimulationHistory";

interface SimulationComparatorProps {
  history: SimulationRecord[];
}

export default function SimulationComparator({ history }: SimulationComparatorProps) {
  const [selectedIds, setSelectedIds] = useState<[string | null, string | null]>([null, null]);

  const sim1 = selectedIds[0] ? history.find((h) => h.id === selectedIds[0]) : null;
  const sim2 = selectedIds[1] ? history.find((h) => h.id === selectedIds[1]) : null;

  const handleSelect = (index: 0 | 1, id: string | null) => {
    setSelectedIds((prev) => {
      const newIds = [...prev] as [string | null, string | null];
      newIds[index] = id;
      return newIds;
    });
  };

  const clearComparison = () => {
    setSelectedIds([null, null]);
  };

  if (history.length === 0) {
    return (
      <Alert className="border-slate-600 bg-slate-700">
        <AlertDescription className="text-slate-400">
          Crie e salve simulações para compará-las lado a lado.
        </AlertDescription>
      </Alert>
    );
  }

  const ComparisonRow = ({
    label,
    value1,
    value2,
    format = "text",
  }: {
    label: string;
    value1?: string | number;
    value2?: string | number;
    format?: "text" | "currency" | "percentage";
  }) => {
    let formatted1 = value1;
    let formatted2 = value2;

    if (format === "currency" && typeof value1 === "number" && typeof value2 === "number") {
      formatted1 = formatCurrency(value1);
      formatted2 = formatCurrency(value2);
    } else if (format === "percentage") {
      formatted1 = `${value1}%`;
      formatted2 = `${value2}%`;
    }

    const isBetter1 =
      format === "currency" && typeof value1 === "number" && typeof value2 === "number"
        ? value1 > value2
        : false;
    const isBetter2 =
      format === "currency" && typeof value1 === "number" && typeof value2 === "number"
        ? value2 > value1
        : false;

    return (
      <div className="grid grid-cols-3 gap-4 p-3 border-b border-slate-600">
        <div className="text-slate-300 font-medium">{label}</div>
        <div className={`text-white ${isBetter1 ? "font-bold text-green-400" : ""}`}>
          {formatted1 || "—"}
        </div>
        <div className={`text-white ${isBetter2 ? "font-bold text-green-400" : ""}`}>
          {formatted2 || "—"}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Seletores */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Selecione Simulações para Comparar</CardTitle>
          <CardDescription className="text-slate-400">
            Escolha até 2 simulações para visualizar lado a lado
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Simulação 1 */}
            <div>
              <label className="text-slate-300 text-sm font-medium block mb-2">Simulação 1</label>
              <Select value={selectedIds[0] || ""} onValueChange={(value) => handleSelect(0, value || null)}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Selecione uma simulação..." />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  {history.map((record) => (
                    <SelectItem key={record.id} value={record.id} className="text-white">
                      {record.nome} ({formatCurrency(record.valorImovel)})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Simulação 2 */}
            <div>
              <label className="text-slate-300 text-sm font-medium block mb-2">Simulação 2</label>
              <Select value={selectedIds[1] || ""} onValueChange={(value) => handleSelect(1, value || null)}>
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Selecione uma simulação..." />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600">
                  {history.map((record) => (
                    <SelectItem key={record.id} value={record.id} className="text-white">
                      {record.nome} ({formatCurrency(record.valorImovel)})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {(sim1 || sim2) && (
            <Button
              variant="outline"
              onClick={clearComparison}
              className="w-full border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              <X className="w-4 h-4 mr-2" />
              Limpar Comparação
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Comparação */}
      {sim1 && sim2 && (
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Comparação Detalhada
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <div className="min-w-max">
                {/* Cabeçalho */}
                <div className="grid grid-cols-3 gap-4 p-3 bg-slate-700 rounded-t-lg font-semibold">
                  <div className="text-slate-300">Métrica</div>
                  <div className="text-white">{sim1.nome}</div>
                  <div className="text-white">{sim2.nome}</div>
                </div>

                {/* Dados Básicos */}
                <div className="bg-slate-700 border-b-2 border-slate-600 p-3">
                  <div className="text-slate-200 font-semibold text-sm mb-2">DADOS BÁSICOS</div>
                </div>

                <ComparisonRow label="Valor do Imóvel" value1={sim1.valorImovel} value2={sim2.valorImovel} format="currency" />
                <ComparisonRow label="Prazo (meses)" value1={sim1.prazoParcela} value2={sim2.prazoParcela} />
                <ComparisonRow label="Ato (R$)" value1={sim1.valorAto} value2={sim2.valorAto} format="currency" />
                <ComparisonRow label="Ato (%)" value1={sim1.percentualAto} value2={sim2.percentualAto} format="percentage" />

                {/* Entrada */}
                <div className="bg-slate-700 border-b-2 border-slate-600 p-3">
                  <div className="text-slate-200 font-semibold text-sm mb-2">ENTRADA</div>
                </div>

                <ComparisonRow label="Financiamento (R$)" value1={sim1.valorFinanciamento} value2={sim2.valorFinanciamento} format="currency" />
                <ComparisonRow label="Vistoria (R$)" value1={sim1.valorVistoria} value2={sim2.valorVistoria} format="currency" />
                <ComparisonRow label="FGTS (R$)" value1={sim1.valorFgts} value2={sim2.valorFgts} format="currency" />

                {/* Parcelas */}
                <div className="bg-slate-700 border-b-2 border-slate-600 p-3">
                  <div className="text-slate-200 font-semibold text-sm mb-2">PARCELAS</div>
                </div>

                <ComparisonRow label="Qtd. Primeiras Mensais" value1={sim1.qtdPrimeirasMensais} value2={sim2.qtdPrimeirasMensais} />
                <ComparisonRow label="Valor Primeiras Mensais" value1={sim1.primeirasMensais} value2={sim2.primeirasMensais} format="currency" />
                <ComparisonRow label="Valor Demais Mensais" value1={sim1.demaisMensais} value2={sim2.demaisMensais} format="currency" />

                {/* Faixas */}
                <div className="bg-slate-700 border-b-2 border-slate-600 p-3">
                  <div className="text-slate-200 font-semibold text-sm mb-2">FAIXAS DE PARCELAS</div>
                </div>

                <ComparisonRow label="Faixa 1 - Qtd" value1={sim1.faixa1Qtd} value2={sim2.faixa1Qtd} />
                <ComparisonRow label="Faixa 1 - Valor" value1={sim1.faixa1Valor} value2={sim2.faixa1Valor} format="currency" />
                <ComparisonRow label="Faixa 2 - Qtd" value1={sim1.faixa2Qtd} value2={sim2.faixa2Qtd} />
                <ComparisonRow label="Faixa 2 - Valor" value1={sim1.faixa2Valor} value2={sim2.faixa2Valor} format="currency" />
                <ComparisonRow label="Faixa 3 - Qtd" value1={sim1.faixa3Qtd} value2={sim2.faixa3Qtd} />
                <ComparisonRow label="Faixa 3 - Valor" value1={sim1.faixa3Valor} value2={sim2.faixa3Valor} format="currency" />
                <ComparisonRow label="Faixa 4 - Qtd" value1={sim1.faixa4Qtd} value2={sim2.faixa4Qtd} />
                <ComparisonRow label="Faixa 4 - Valor" value1={sim1.faixa4Valor} value2={sim2.faixa4Valor} format="currency" />

                {/* Totais */}
                <div className="bg-slate-700 border-b-2 border-slate-600 p-3">
                  <div className="text-slate-200 font-semibold text-sm mb-2">TOTAIS</div>
                </div>

                <ComparisonRow label="Total Fluxo" value1={sim1.totalFluxoPersonalizado} value2={sim2.totalFluxoPersonalizado} format="currency" />
                <div className="grid grid-cols-3 gap-4 p-3 bg-slate-700 rounded-b-lg border-t border-slate-600">
                  <div className="text-slate-300 font-medium">Status</div>
                  <div className={`font-bold ${sim1.validacaoEntrada === "OK ENTRADA" ? "text-green-400" : "text-red-400"}`}>
                    {sim1.validacaoEntrada}
                  </div>
                  <div className={`font-bold ${sim2.validacaoEntrada === "OK ENTRADA" ? "text-green-400" : "text-red-400"}`}>
                    {sim2.validacaoEntrada}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {(selectedIds[0] || selectedIds[1]) && !(sim1 && sim2) && (
        <Alert className="border-yellow-500 bg-yellow-50 dark:bg-yellow-950">
          <AlertDescription className="text-yellow-800 dark:text-yellow-200">
            Selecione 2 simulações para ativar a comparação.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
