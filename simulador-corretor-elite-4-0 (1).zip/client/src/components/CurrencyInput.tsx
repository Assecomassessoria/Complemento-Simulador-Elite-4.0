import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatCurrency } from "@/lib/simulatorCalc";

interface CurrencyInputProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  placeholder?: string;
  disabled?: boolean;
}

export default function CurrencyInput({
  label,
  value,
  onChange,
  placeholder = "0",
  disabled = false,
}: CurrencyInputProps) {
  // Converter número para string apenas com dígitos
  const displayValue = value.toString();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Remover tudo que não é dígito
    const cleanValue = e.target.value.replace(/\D/g, "");
    
    // Converter para número
    const numValue = cleanValue ? parseInt(cleanValue, 10) : 0;
    
    onChange(numValue);
  };

  return (
    <div>
      <Label className="text-slate-300">{label}</Label>
      <div className="relative mt-2">
        <span className="absolute left-3 top-3 text-slate-400 pointer-events-none">R$</span>
        <Input
          type="text"
          value={displayValue}
          onChange={handleChange}
          placeholder={placeholder}
          disabled={disabled}
          className="bg-slate-700 border-slate-600 text-white pl-10 font-mono"
          inputMode="numeric"
        />
        <span className="absolute right-3 top-3 text-slate-400 text-sm">
          {formatCurrency(value)}
        </span>
      </div>
    </div>
  );
}
