import { useState, useEffect, useCallback } from "react";

export interface SimulationRecord {
  id: string;
  timestamp: number;
  nome: string;
  descricao?: string;
  // Dados do simulador
  valorImovel: number;
  prazoParcela: number;
  valorAto: number;
  valorFinanciamento: number;
  valorFgts: number;
  valorVistoria: number;
  qtdPrimeirasMensais: number;
  faixa1Qtd: number;
  faixa1Valor: number;
  faixa2Qtd: number;
  faixa2Valor: number;
  faixa3Qtd: number;
  faixa3Valor: number;
  percentualAto: number;
  percentualPrimeiras: number;
  // Resultados calculados
  primeirasMensais: number;
  demaisMensais: number;
  faixa4Qtd: number;
  faixa4Valor: number;
  totalFluxoPersonalizado: number;
  validacaoEntrada: string;
}

const STORAGE_KEY = "simulador_elite_history";
const MAX_RECORDS = 50;

export function useSimulationHistory() {
  const [history, setHistory] = useState<SimulationRecord[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  // Carregar histórico do localStorage
  useEffect(() => {
    const loadHistory = () => {
      try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
          const parsed = JSON.parse(stored);
          setHistory(Array.isArray(parsed) ? parsed : []);
        }
      } catch (error) {
        console.error("Erro ao carregar histórico:", error);
      }
      setIsLoaded(true);
    };

    loadHistory();
  }, []);

  // Salvar simulação
  const saveSimulation = useCallback(
    (simulation: Omit<SimulationRecord, "id" | "timestamp">) => {
      const newRecord: SimulationRecord = {
        ...simulation,
        id: `sim_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        timestamp: Date.now(),
      };

      const updated = [newRecord, ...history].slice(0, MAX_RECORDS);
      setHistory(updated);

      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch (error) {
        console.error("Erro ao salvar simulação:", error);
      }

      return newRecord;
    },
    [history]
  );

  // Atualizar simulação
  const updateSimulation = useCallback(
    (id: string, updates: Partial<SimulationRecord>) => {
      const updated = history.map((record) =>
        record.id === id ? { ...record, ...updates } : record
      );
      setHistory(updated);

      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch (error) {
        console.error("Erro ao atualizar simulação:", error);
      }
    },
    [history]
  );

  // Deletar simulação
  const deleteSimulation = useCallback(
    (id: string) => {
      const updated = history.filter((record) => record.id !== id);
      setHistory(updated);

      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch (error) {
        console.error("Erro ao deletar simulação:", error);
      }
    },
    [history]
  );

  // Limpar histórico
  const clearHistory = useCallback(() => {
    setHistory([]);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (error) {
      console.error("Erro ao limpar histórico:", error);
    }
  }, []);

  // Obter simulação por ID
  const getSimulation = useCallback(
    (id: string) => {
      return history.find((record) => record.id === id);
    },
    [history]
  );

  return {
    history,
    isLoaded,
    saveSimulation,
    updateSimulation,
    deleteSimulation,
    clearHistory,
    getSimulation,
  };
}
